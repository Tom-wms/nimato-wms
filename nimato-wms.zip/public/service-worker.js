// Basic service worker for PWA support
self.addEventListener('install', () => self.skipWaiting());